 

 Sprite = Class:extend {
 
 }